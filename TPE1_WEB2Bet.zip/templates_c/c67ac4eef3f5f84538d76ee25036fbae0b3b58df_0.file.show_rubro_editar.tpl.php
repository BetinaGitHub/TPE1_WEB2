<?php
/* Smarty version 3.1.34-dev-7, created on 2020-12-01 01:41:03
  from 'C:\xampp\htdocs\WEB2\TPE1_WEB2\templates\show_rubro_editar.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5fc5911f16c8d2_94625028',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c67ac4eef3f5f84538d76ee25036fbae0b3b58df' => 
    array (
      0 => 'C:\\xampp\\htdocs\\WEB2\\TPE1_WEB2\\templates\\show_rubro_editar.tpl',
      1 => 1606517026,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:show_solapas.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_5fc5911f16c8d2_94625028 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<!--------- Solapas ------------>
<?php $_smarty_tpl->_subTemplateRender("file:show_solapas.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<!--------- Pantalla edicion ------------>
<div class='container d-flex justify-content-center align-items-center"'>
<form action ='<?php echo BASE_URL;?>
upd-rubro' method = "POST">
 <table class="table table-bordered table-sm">
  <thead class="bg-secondary text-white" >
    <tr>
      <th scope="col">Código</th>
      <th scope="col">Descripción rubro</th>
    </tr>
  </thead>
  <tbody>
     <tr>
      <td><input type="text" class="form-control" name="idrubro" readonly value="<?php echo $_smarty_tpl->tpl_vars['rubro']->value->id;?>
"></td>
      <td><input  name="descrubro"  type="text" class="form-control" value=<?php echo $_smarty_tpl->tpl_vars['rubro']->value->descripcion;?>
></td>
      <td ><button type="submit" class="btn btn-dark btn-sm">Modificar</button></td>
    </tr>    
  <tbody>
  </table>
</form>
</div> 
<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>  <?php }
}
