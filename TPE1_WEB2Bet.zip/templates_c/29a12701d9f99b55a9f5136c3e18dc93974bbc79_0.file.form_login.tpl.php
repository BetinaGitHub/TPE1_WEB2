<?php
/* Smarty version 3.1.34-dev-7, created on 2020-11-30 22:28:23
  from 'C:\xampp\htdocs\WEB2\TPE1_WEB2\templates\form_login.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5fc563f79417a1_59499139',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '29a12701d9f99b55a9f5136c3e18dc93974bbc79' => 
    array (
      0 => 'C:\\xampp\\htdocs\\WEB2\\TPE1_WEB2\\templates\\form_login.tpl',
      1 => 1606677618,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_5fc563f79417a1_59499139 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender('file:header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<main class="container"> <!-- inicio del contenido pricipal -->
    <div class="mt-5 w-25 mx-auto">
        <form method="POST" action="verify">
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" class="form-control" id="email" name="email" aria-describedby="usernameHelp">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" id="passw" name="passw">
            </div>
            <?php if ($_smarty_tpl->tpl_vars['error']->value) {?>
                <div class="alert alert-danger">
                    <?php echo $_smarty_tpl->tpl_vars['error']->value;?>

                </div>
            <?php }?>
            <button type="submit" name="ingresar" value="ingresar" class="btn btn-primary bg-dark">Ingresar</button>
        </form>
        <a href='register' class="fourth btn btn-primary bg-dark"> Registrarse</a>
        </div>
<?php $_smarty_tpl->_subTemplateRender('file:footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
