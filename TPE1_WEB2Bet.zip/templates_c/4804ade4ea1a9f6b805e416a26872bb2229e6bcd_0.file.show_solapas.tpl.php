<?php
/* Smarty version 3.1.34-dev-7, created on 2020-12-01 04:28:15
  from 'C:\xampp\htdocs\WEB2\TPE1_WEB2\templates\show_solapas.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5fc5b84f091b70_79311616',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4804ade4ea1a9f6b805e416a26872bb2229e6bcd' => 
    array (
      0 => 'C:\\xampp\\htdocs\\WEB2\\TPE1_WEB2\\templates\\show_solapas.tpl',
      1 => 1606793282,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5fc5b84f091b70_79311616 (Smarty_Internal_Template $_smarty_tpl) {
?><!--------- Solapas ------------>

<div class='container'>
<ul class="nav nav-tabs">
  <li class="nav-item">
    <a class="nav-link text-success" href="<?php echo BASE_URL;?>
abm-tools">Maquinarias</a>
  </li>
  <li class="nav-item">
    <a class="nav-link  text-dark" href="<?php echo BASE_URL;?>
modi-rubros">Rubros</a>
  </li>
  <li class="nav-item">
    <a class="nav-link  text-dark" href="<?php echo BASE_URL;?>
abm-users">Usuarios</a>
  </li>
</ul>
</div><?php }
}
