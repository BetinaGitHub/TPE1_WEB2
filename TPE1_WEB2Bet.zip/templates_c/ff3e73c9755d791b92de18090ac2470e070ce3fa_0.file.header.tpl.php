<?php
/* Smarty version 3.1.34-dev-7, created on 2020-12-01 03:47:40
  from 'C:\xampp\htdocs\WEB2\TPE1_WEB2\templates\header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5fc5aecc7368e5_18722103',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ff3e73c9755d791b92de18090ac2470e070ce3fa' => 
    array (
      0 => 'C:\\xampp\\htdocs\\WEB2\\TPE1_WEB2\\templates\\header.tpl',
      1 => 1606790856,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5fc5aecc7368e5_18722103 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <base href="<?php echo '<?=';?>
BASE_URL<?php echo '?>';?>
">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maquinarias Agrícolas</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
     integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
     <!-- development version, includes helpful console warnings -->
     
    <?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/vue/dist/vue.js"><?php echo '</script'; ?>
>
</head>
<body>
  <header>
    <nav class="navbar navbar-expand-lg navbar-dark bg-success">
      <a class="navbar-brand" href="<?php echo BASE_URL;?>
home">MAQUINARIAS AGRICOLAS USADAS</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav d-flex w-100">
           <li class="nav-item active">
                <a class="nav-link" href="<?php echo BASE_URL;?>
abm-tools">Administrar Datos<span class="sr-only">(current)</span></a>
            </li>
          
          <?php if (!(isset($_SESSION['EMAIL_USER']))) {?>
	          <li class="nav-item ml-auto">
              <a class="nav-link" href="<?php echo BASE_URL;?>
login">Login</a>
            </li>    
          <?php } else { ?>
            <li class="nav-item ml-auto"> 
             <?php if (($_SESSION['ROL_USER'] == 1)) {?>
                 <a class="nav-link" href="<?php echo BASE_URL;?>
logout"><?php echo $_SESSION['EMAIL_USER'];?>
( Administrador  ) (LOGOUT)</a>
              <?php } else { ?>
                <a class="nav-link" href="<?php echo BASE_URL;?>
logout"><?php echo $_SESSION['EMAIL_USER'];?>
( Invitado  ) (LOGOUT)</a>
             <?php }?>  
            </li>            	
          <?php }?>
        </ul>
      </div>
    </nav>
  </header>
  <main class='row'>  
<?php }
}
