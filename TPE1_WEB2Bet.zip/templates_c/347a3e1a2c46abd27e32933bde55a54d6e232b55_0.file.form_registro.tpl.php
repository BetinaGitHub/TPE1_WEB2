<?php
/* Smarty version 3.1.34-dev-7, created on 2020-12-01 01:19:25
  from 'C:\xampp\htdocs\WEB2\TPE1_WEB2\templates\form_registro.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5fc58c0dbb7c17_55153087',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '347a3e1a2c46abd27e32933bde55a54d6e232b55' => 
    array (
      0 => 'C:\\xampp\\htdocs\\WEB2\\TPE1_WEB2\\templates\\form_registro.tpl',
      1 => 1606600101,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_5fc58c0dbb7c17_55153087 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender('file:header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<main class="container"> <!-- inicio del contenido pricipal -->
    <div class="mt-5 w-25 mx-auto">
        <form method="POST" action="verifyNewUser">
            <div class="form-group">
                <label for="username">Apellido y Nombre</label>
                <input type="username" class="form-control" id="username" name="username" aria-describedby="usernameHelp">
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" class="form-control" id="email" name="email" aria-describedby="usernameHelp">
            </div>
            <div class="form-group">
                <label for="password1">Password</label>
                <input type="password" class="form-control" id="password1" name="password1">
            </div>
            <div class="form-group">
                <label for="password2">Repetir Password</label>
                <input type="password" class="form-control" id="password2" name="password2">
            </div>
            <?php if ($_smarty_tpl->tpl_vars['error']->value) {?>
                <div class="alert alert-danger">
                    <?php echo $_smarty_tpl->tpl_vars['error']->value;?>

                </div>
            <?php }?>
            <button type="submit" name="registrarse" value="registrarse" class="btn btn-primary bg-dark">Registrarse</button>
          </form>
    </div>
<?php $_smarty_tpl->_subTemplateRender('file:footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
