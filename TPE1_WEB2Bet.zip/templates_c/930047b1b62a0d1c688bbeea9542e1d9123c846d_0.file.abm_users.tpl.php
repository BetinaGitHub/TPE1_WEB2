<?php
/* Smarty version 3.1.34-dev-7, created on 2020-12-01 15:02:25
  from 'C:\xampp\htdocs\WEB2\TPE1_WEB2\templates\abm_users.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5fc64cf18a7bc2_68090288',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '930047b1b62a0d1c688bbeea9542e1d9123c846d' => 
    array (
      0 => 'C:\\xampp\\htdocs\\WEB2\\TPE1_WEB2\\templates\\abm_users.tpl',
      1 => 1606825259,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:show_solapas.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_5fc64cf18a7bc2_68090288 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?> 
<?php $_smarty_tpl->_subTemplateRender("file:show_solapas.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<!---------Alta/Edit user------------>
<div class="container">
  <div class="col-12">
    <form action="<?php echo BASE_URL;?>
updateRol" method="POST" class="my-2" >
      <input name="id" value="<?php if ((isset($_smarty_tpl->tpl_vars['user']->value))) {
echo $_smarty_tpl->tpl_vars['user']->value->id;
}?>" type="hidden" >
      <div class="row">
        <div class="col-4">
          <div class="form-group">
               <label>Nombre</label>
               <input name="descripcion" value="<?php if ((isset($_smarty_tpl->tpl_vars['user']->value))) {?> <?php echo $_smarty_tpl->tpl_vars['user']->value->username;
}?>" type="text" class="form-control" >
          </div>
        </div>
        <div class="col-2">
          <div class="form-group">
            <label>e-mail</label>
            <input name="modelo" value="<?php if ((isset($_smarty_tpl->tpl_vars['user']->value))) {?> <?php echo $_smarty_tpl->tpl_vars['user']->value->email;
}?>" type="text" class="form-control">
          </div>
        </div>  
        <div class="col-3">
          <div class="form-group">
            <label>Contraseña</label>
            <input name="passw" type="text" class="form-control" value=<?php if ((isset($_smarty_tpl->tpl_vars['user']->value))) {?> <?php echo $_smarty_tpl->tpl_vars['user']->value->passw;
}?>>
          </div> 
        </div>
      </div>

      <div class="row">
        <div class="col-12 form-group">
          <label>Rol</label>
         <input name="rol" type="text" class="form-control" value=<?php if ((isset($_smarty_tpl->tpl_vars['user']->value))) {?> <?php echo $_smarty_tpl->tpl_vars['user']->value->rol;
}?>>
       
        </div>
      </div>
      
       
        <div class="col-3 form-group">
          <button type="submit" class="btn btn-dark btn-sm">Cambiar ROL</button>
        </div>
      </div>
    </form>
  </div>
</div>


<!---------Alta/Edit user------------>
<div class='container'>
  <div class="tab-content overflow-auto" id="myTabContent">
    <table class="table table-bordered table-hover table-sm">
      <thead class="bg-secondary text-white">
        <tr>
          <th scope="col">User</th>
          <th scope="col">e-mail</th>
          <th scope="col">Contraseña</th>
          <th scope="col">Rol</th>
          <th scope="col">Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['users']->value, 'user');
$_smarty_tpl->tpl_vars['user']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['user']->value) {
$_smarty_tpl->tpl_vars['user']->do_else = false;
?>              
          <tr>
            <td><?php echo $_smarty_tpl->tpl_vars['user']->value->username;?>
</td>
            <td><?php echo $_smarty_tpl->tpl_vars['user']->value->email;?>
</td>
            <td><?php echo $_smarty_tpl->tpl_vars['user']->value->passw;?>
</td>
            <td><?php echo $_smarty_tpl->tpl_vars['user']->value->rol;?>
</td>
      
            <td class="d-flex ">
              <a class="btn btn-success btn-sm" href="<?php echo BASE_URL;?>
modi-rol/<?php echo $_smarty_tpl->tpl_vars['user']->value->id;?>
">Editar</a>
              <a class="btn btn-danger btn-sm"  href="<?php echo BASE_URL;?>
eliminar-user/<?php echo $_smarty_tpl->tpl_vars['user']->value->id;?>
">Eliminar</a>
            </td>
          </tr>     
        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?> 
        <?php if (count($_smarty_tpl->tpl_vars['users']->value) == 0) {?>
          <tr><td> No se han encontrado usuarios </td></tr>
        <?php }?>
      </tbody>
    </table>
  </div> 
</div> 

<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>  <?php }
}
