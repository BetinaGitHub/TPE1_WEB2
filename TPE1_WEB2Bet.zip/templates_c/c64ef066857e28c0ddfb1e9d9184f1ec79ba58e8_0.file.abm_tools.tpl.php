<?php
/* Smarty version 3.1.34-dev-7, created on 2020-12-01 14:59:52
  from 'C:\xampp\htdocs\WEB2\TPE1_WEB2\templates\abm_tools.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5fc64c58396069_87450591',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c64ef066857e28c0ddfb1e9d9184f1ec79ba58e8' => 
    array (
      0 => 'C:\\xampp\\htdocs\\WEB2\\TPE1_WEB2\\templates\\abm_tools.tpl',
      1 => 1606825259,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:show_solapas.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_5fc64c58396069_87450591 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?> 
<?php $_smarty_tpl->_subTemplateRender("file:show_solapas.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<!---------Alta/Edit maquinarias------------>
<div class="container">
  <div class="col-12">
    <form action="<?php echo BASE_URL;
echo $_smarty_tpl->tpl_vars['accion']->value;?>
" method="POST" class="my-2" enctype="multipart/form-data">
      <input name="id" value="<?php if ((isset($_smarty_tpl->tpl_vars['tool']->value))) {
echo $_smarty_tpl->tpl_vars['tool']->value->id;
}?>" type="hidden" >
      <div class="row">
        <div class="col-3">
          <div class="form-group-sm">
            <label>Rubro</label>
              <select class="form-control" name="rubro">
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['rubros']->value, 'rubro');
$_smarty_tpl->tpl_vars['rubro']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['rubro']->value) {
$_smarty_tpl->tpl_vars['rubro']->do_else = false;
?>
                  <option value="<?php echo $_smarty_tpl->tpl_vars['rubro']->value->id;?>
"
                    <?php ob_start();
echo $_smarty_tpl->tpl_vars['rubro']->value->id;
$_prefixVariable1 = ob_get_clean();
ob_start();
echo $_smarty_tpl->tpl_vars['tool']->value->idRubro;
$_prefixVariable2 = ob_get_clean();
if ($_prefixVariable1 == $_prefixVariable2) {?> 
                      <?php echo " selected";?>

                    <?php }?>   
                  ><?php echo $_smarty_tpl->tpl_vars['rubro']->value->descripcion;?>
</option>
                 <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
              </select>
          </div>
        </div>
        <div class="col-4">
          <div class="form-group-sm">
               <label>Maquinaria Usada</label>
               <input name="descripcion" value="<?php if ((isset($_smarty_tpl->tpl_vars['tool']->value))) {?> <?php echo $_smarty_tpl->tpl_vars['tool']->value->descripcion;
}?>" type="text" class="form-control" >
          </div>
        </div>
        <div class="col-2">
          <div class="form-group-sm">
            <label>Modelo</label>
            <input name="modelo" value="<?php if ((isset($_smarty_tpl->tpl_vars['tool']->value))) {?> <?php echo $_smarty_tpl->tpl_vars['tool']->value->modelo;
}?>" type="text" class="form-control">
          </div>
        </div>  
        <div class="col-3">
          <div class="form-group-sm">
            <label>Precio</label>
            <input name="precio" type="number" class="form-control" value=<?php if ((isset($_smarty_tpl->tpl_vars['tool']->value))) {?> <?php echo $_smarty_tpl->tpl_vars['tool']->value->precio;
}?>>
          </div> 
        </div>
      </div>

      <div class="row">
        <div class="col-12 form-group-sm">
          <label>Descripción de la maquinaria</label>
          <textarea name="notas" class="form-control" rows="2"><?php if ((isset($_smarty_tpl->tpl_vars['tool']->value))) {?> <?php echo $_smarty_tpl->tpl_vars['tool']->value->notas;
}?></textarea>
        </div>
      </div>
      
      <div class="row">
        <div class="form-group-sm col-9">
          <label>Seleccionar imagen</label>
          <input type="file" name="img_name" id="imageToUpload">
 
          <input type="text" name="img_name" id="imageToUpload" value=<?php if ((isset($_smarty_tpl->tpl_vars['tool']->value))) {?> <?php echo $_smarty_tpl->tpl_vars['tool']->value->imagen;
}?> > 
          <label class="form-check-label" for=" ">Eliminar</label>     
          <input type="checkbox"  name="borrarImg" >
                 <div class="col-3 form-group">
          <?php if ((isset($_smarty_tpl->tpl_vars['tool']->value))) {?>
            <img width="80px" src="../uploads/<?php echo $_smarty_tpl->tpl_vars['tool']->value->imagen;?>
">
          <?php } else { ?>
            <p class="bg-info text-white text-center">No hay imagen ilustrativa</p>
          <?php }?>
           </div> 
          </div>
      
        <div class="col-3 form-group">
          <button type="submit" class="btn btn-dark btn-sm"><?php echo $_smarty_tpl->tpl_vars['boton']->value;?>
</button>
        </div>

      </div>
    </form>
  </div>
</div>

<div class='container'>
  <nav class="navbar navbar-light bg-light">
    <form class="form-inline" action="<?php echo BASE_URL;?>
search-tools" method="POST">
      <input name="search" class="form-control md-8" type="search" placeholder="Búsqueda avanzada" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Buscar</button>
    </form>
  </nav>
  <div class="tab-content overflow-auto table-sm" id="myTabContent">
    <table class="table table-bordered table-hover table-sm">
      <thead class="bg-secondary text-white">
        <tr>
          <th scope="col">Maquinaria</th>
          <th scope="col">Rubro</th>
          <th scope="col">Modelo</th>
          <th scope="col">Descripcion</th>
          <th scope="col">Precio</th>
          <th scope="col">Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tools']->value, 'tool');
$_smarty_tpl->tpl_vars['tool']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['tool']->value) {
$_smarty_tpl->tpl_vars['tool']->do_else = false;
?>              
          <tr>
            <td><?php echo $_smarty_tpl->tpl_vars['tool']->value->descripcion;?>
</td>
            <td><?php echo $_smarty_tpl->tpl_vars['tool']->value->descrubro;?>
</td>
            <td><?php echo $_smarty_tpl->tpl_vars['tool']->value->modelo;?>
</td>
            <td><?php echo $_smarty_tpl->tpl_vars['tool']->value->notas;?>
</td>
            <td><?php echo $_smarty_tpl->tpl_vars['tool']->value->precio;?>
</td> 
            <td class="d-flex ">
              <a class="btn btn-success btn-sm" href="<?php echo BASE_URL;?>
editar-tool/<?php echo $_smarty_tpl->tpl_vars['tool']->value->id;?>
">Editar</a>
              <a class="btn btn-danger btn-sm"  href="<?php echo BASE_URL;?>
eliminar/<?php echo $_smarty_tpl->tpl_vars['tool']->value->id;?>
">Eliminar</a>
            </td>
          </tr>     
        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?> 
        <?php if (count($_smarty_tpl->tpl_vars['tools']->value) == 0) {?>
          <tr><td> No se han encontrado herramientas </td></tr>
        <?php }?>
      </tbody>
    </table>
  </div> 
</div> 

<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>  <?php }
}
