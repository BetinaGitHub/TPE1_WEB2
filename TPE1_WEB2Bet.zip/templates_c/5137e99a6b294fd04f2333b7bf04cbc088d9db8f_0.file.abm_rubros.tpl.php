<?php
/* Smarty version 3.1.34-dev-7, created on 2020-11-30 23:16:10
  from 'C:\xampp\htdocs\WEB2\TPE1_WEB2\templates\abm_rubros.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5fc56f2a6625d7_30276530',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5137e99a6b294fd04f2333b7bf04cbc088d9db8f' => 
    array (
      0 => 'C:\\xampp\\htdocs\\WEB2\\TPE1_WEB2\\templates\\abm_rubros.tpl',
      1 => 1606690247,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:show_solapas.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_5fc56f2a6625d7_30276530 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
$_smarty_tpl->_subTemplateRender("file:show_solapas.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?> 

<!---------Alta rubros------------>

<div class='container'>
<form action="insertar-rubro" method="POST" class="my-2">
  <div class="row">
    <div class="col-6">
      <div class="form-group">
        <label>Descripcion rubro</label>
        <input name="desc_rubro" type="text" class="form-control">
      </div>
    </div>
  </div>
  <button type="submit" class="btn btn-dark btn-sm">Agregar</button>
</form>

<!---------Lista de  rubros------------>

<div class="tab-content overflow-auto" id="myTabContent">
  <table class="table table-bordered table-hover table-sm">
     <thead  class="bg-secondary text-white">
      <tr>
        <th scope="col">Código</th>
        <th scope="col">Descripcion rubro</th>
        <th scope="col">Acciones</th>
      </tr>
    </thead> 
    <tbody>
      <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['rubros']->value, 'rubro');
$_smarty_tpl->tpl_vars['rubro']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['rubro']->value) {
$_smarty_tpl->tpl_vars['rubro']->do_else = false;
?>              
        <tr>
          <td><?php echo $_smarty_tpl->tpl_vars['rubro']->value->id;?>
</td>
          <td><?php echo $_smarty_tpl->tpl_vars['rubro']->value->descripcion;?>
</td>
          <td class="d-flex no-wrap">
            <a class="btn btn-success btn-sm" href="editar-rubro/<?php echo $_smarty_tpl->tpl_vars['rubro']->value->id;?>
">Editar</a>
            <a class="btn btn-danger btn-sm" href="eliminar-rubro/<?php echo $_smarty_tpl->tpl_vars['rubro']->value->id;?>
">Eliminar</a>
          </td>
        </tr>     
        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?> 
        <?php if (count($_smarty_tpl->tpl_vars['rubros']->value) == 0) {?>
          <tr><td> No se han encontrado rubros </td></tr>
        <?php }?>
    </tbody>
  </table>
</div> 
</div> 

<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>  <?php }
}
