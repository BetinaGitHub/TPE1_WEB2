<?php
/* Smarty version 3.1.34-dev-7, created on 2020-11-30 21:28:34
  from 'C:\xampp\htdocs\WEB2\TPE1_WEB2\templates\show_rubros.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5fc555f2041135_69747903',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6d732401ad812871b2851f16a78ddd5697b6e243' => 
    array (
      0 => 'C:\\xampp\\htdocs\\WEB2\\TPE1_WEB2\\templates\\show_rubros.tpl',
      1 => 1606690640,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
  ),
),false)) {
function content_5fc555f2041135_69747903 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<div class="col-2 ">
  <ul class='list-group'  style='max-width: 200px'  >
    <a class='list-group-item list-group-item-action text-white bg-success'   href='<?php echo BASE_URL;?>
home'>TODOS</a>
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['rubros']->value, 'rubro');
$_smarty_tpl->tpl_vars['rubro']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['rubro']->value) {
$_smarty_tpl->tpl_vars['rubro']->do_else = false;
?> 
      <a class='list-group-item list-group-item-action text-white bg-dark' href='<?php echo BASE_URL;?>
filtrar/<?php echo $_smarty_tpl->tpl_vars['rubro']->value->id;?>
'><?php echo $_smarty_tpl->tpl_vars['rubro']->value->descripcion;?>
</a>
    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
  </ul> 
</div><?php }
}
