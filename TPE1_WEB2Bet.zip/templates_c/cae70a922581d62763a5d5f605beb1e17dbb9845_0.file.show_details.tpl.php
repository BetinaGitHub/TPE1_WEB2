<?php
/* Smarty version 3.1.34-dev-7, created on 2020-11-30 23:54:10
  from 'C:\xampp\htdocs\WEB2\TPE1_WEB2\templates\show_details.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5fc5781210f122_39152256',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cae70a922581d62763a5d5f605beb1e17dbb9845' => 
    array (
      0 => 'C:\\xampp\\htdocs\\WEB2\\TPE1_WEB2\\templates\\show_details.tpl',
      1 => 1606771575,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5fc5781210f122_39152256 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="card">

  
  <div class="form-group">
    <?php if ($_smarty_tpl->tpl_vars['tools']->value->imagen) {?>
      <img width="280px" src="../uploads/<?php echo $_smarty_tpl->tpl_vars['tools']->value->imagen;?>
">
    <?php } else { ?>
      <h3 class="bg-info text-white text-center">No hay imagen ilustrativa</h3>
    <?php }?>
  </div>
  <div class="card-body">
    <h4 class="card-title"><?php echo $_smarty_tpl->tpl_vars['tools']->value->descripcion;?>
</h5>
    <p class="card-text"><?php echo $_smarty_tpl->tpl_vars['tools']->value->notas;?>
</p>
    <p class="card-text">Modelo: <?php echo $_smarty_tpl->tpl_vars['tools']->value->modelo;?>
</p>
    <p class="card-text">Precio: <?php echo $_smarty_tpl->tpl_vars['tools']->value->precio;?>
</p>
   
    <input name = "idtool" id="idtool" type = "hidden" value = <?php echo $_smarty_tpl->tpl_vars['tools']->value->id;?>
>
  </div> 
</div>
<a class="col-4 btn bg-dark text-white " href="<?php echo BASE_URL;?>
">Volver</a>
<?php }
}
