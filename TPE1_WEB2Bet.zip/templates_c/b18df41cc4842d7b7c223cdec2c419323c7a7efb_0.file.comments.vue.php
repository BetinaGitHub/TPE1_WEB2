<?php
/* Smarty version 3.1.34-dev-7, created on 2020-12-02 01:11:40
  from 'C:\xampp\htdocs\WEB2\TPE1_WEB2\templates\vue\comments.vue' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5fc6dbbcd52053_07224355',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b18df41cc4842d7b7c223cdec2c419323c7a7efb' => 
    array (
      0 => 'C:\\xampp\\htdocs\\WEB2\\TPE1_WEB2\\templates\\vue\\comments.vue',
      1 => 1606867868,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5fc6dbbcd52053_07224355 (Smarty_Internal_Template $_smarty_tpl) {
?>
<section id="app">
    <div class="tab-content overflow-auto" id="myTabContent">
        <table class="table table-bordered table-hover table-sm">
            <thead  class="bg-secondary text-white">
            <tr>
                <th scope="col">Comentario</th>
                <th scope="col">Puntuación</th>
                <th scope="col" v-if="rol == 1">Acción</th>           
            </tr>
            </thead> 
            <tbody>
                <tr v-for="comment in comments" v-bind:class ="{'bg-info': comment.puntaje == 5}">
                            
                    <td>{{ comment.comment }}</td>
                    <td>{{ comment.puntaje }}</td>
                    <td class="d-flex no-wrap" v-if="rol == 0">
                       <button class='btn btn-dark btn-sm' v-on:click="rmComment(comment.id)" v-if="rol == 0">Eliminar</button>
                    </td>

                </tr>     
            </tbody>
        </table>
    </div> 
</section>
<?php }
}
