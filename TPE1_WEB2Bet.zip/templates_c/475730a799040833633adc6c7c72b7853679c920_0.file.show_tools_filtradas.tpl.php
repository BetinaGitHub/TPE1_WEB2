<?php
/* Smarty version 3.1.34-dev-7, created on 2020-11-30 23:15:42
  from 'C:\xampp\htdocs\WEB2\TPE1_WEB2\templates\show_tools_filtradas.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5fc56f0ed94577_72973060',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '475730a799040833633adc6c7c72b7853679c920' => 
    array (
      0 => 'C:\\xampp\\htdocs\\WEB2\\TPE1_WEB2\\templates\\show_tools_filtradas.tpl',
      1 => 1606694022,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_5fc56f0ed94577_72973060 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="row w-75" >  
  <table class="table table-bordered table-sm table-hover">
    <thead class='bg-secondary text-white'>
      <tr>
        <th scope="col">Maquinaria</th>
        <th scope="col">Rubro</th>
        <th scope="col">Modelo</th>
        <th scope="col"></th>
      </tr>
    </thead>
    <tbody>
      <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tools']->value, 'tool');
$_smarty_tpl->tpl_vars['tool']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['tool']->value) {
$_smarty_tpl->tpl_vars['tool']->do_else = false;
?>              
        <tr>
          <td><?php echo $_smarty_tpl->tpl_vars['tool']->value->descripcion;?>
</td>
          <td><?php echo $_smarty_tpl->tpl_vars['tool']->value->descrubro;?>
</td>
          <td><?php echo $_smarty_tpl->tpl_vars['tool']->value->modelo;?>
</td>
          <td><?php echo $_smarty_tpl->tpl_vars['tool']->value->notas;?>
</td> 
          <td class="d-flex no-wrap">
            <a class="btn btn-dark btn-sm" href="<?php echo BASE_URL;?>
detalles/<?php echo $_smarty_tpl->tpl_vars['tool']->value->id;?>
">Detalles</a>
          </td>
        </tr>     
      <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?> 
      <?php if (count($_smarty_tpl->tpl_vars['tools']->value) == 0) {?>
        <tr><td> No se han encontrado herramientas </td></tr>
      <?php }?>
    </tbody> 
  </table>
</div> 

<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>    <?php }
}
