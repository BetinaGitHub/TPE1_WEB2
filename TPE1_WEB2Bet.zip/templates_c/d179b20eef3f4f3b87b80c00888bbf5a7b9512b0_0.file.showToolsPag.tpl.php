<?php
/* Smarty version 3.1.34-dev-7, created on 2020-12-01 14:50:46
  from 'C:\xampp\htdocs\WEB2\TPE1_WEB2\templates\showToolsPag.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5fc64a36798619_90285519',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd179b20eef3f4f3b87b80c00888bbf5a7b9512b0' => 
    array (
      0 => 'C:\\xampp\\htdocs\\WEB2\\TPE1_WEB2\\templates\\showToolsPag.tpl',
      1 => 1606825259,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_5fc64a36798619_90285519 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="row w-75" >  
  <input type="hidden" name="cant_paginas" value=<?php echo $_smarty_tpl->tpl_vars['tot_paginas']->value;?>
>
  <table class="table table-bordered table-sm table-hover">
    <thead class='bg-secondary text-white'>
      <tr>
        <th scope="col">Maquinaria</th>
        <th scope="col">Rubro</th>
        <th scope="col">Modelo</th>
        <th scope="col">Notas</th>
        <th scope="col">Detalles</th>
      </tr>
    </thead>
    <tbody>
      <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tools']->value, 'tool');
$_smarty_tpl->tpl_vars['tool']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['tool']->value) {
$_smarty_tpl->tpl_vars['tool']->do_else = false;
?>              
        <tr>
          <td><?php echo $_smarty_tpl->tpl_vars['tool']->value->descripcion;?>
</td>
          <td><?php echo $_smarty_tpl->tpl_vars['tool']->value->descrubro;?>
</td>
          <td><?php echo $_smarty_tpl->tpl_vars['tool']->value->modelo;?>
</td>
          <td><?php echo $_smarty_tpl->tpl_vars['tool']->value->notas;?>
</td> 
          <td class="d-flex no-wrap">
            <a class="btn btn-dark btn-sm" href="<?php echo BASE_URL;?>
detalles/<?php echo $_smarty_tpl->tpl_vars['tool']->value->id;?>
">Detalles</a>
          </td>
        </tr>     
      <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?> 
      <?php if (count($_smarty_tpl->tpl_vars['tools']->value) == 0) {?>
        <tr><td> No se han encontrado herramientas </td></tr>
      <?php }?>
    </tbody> 
  </table>
  <div class="col" > 
  <nav aria-label="Page navigation example" class="d-flex justify-content-center">
    <ul class="pagination">   
      <li class="page-item">
          <a class="page-link" <?php if ($_smarty_tpl->tpl_vars['actual_page']->value > 1) {?> href= '<?php echo BASE_URL;?>
home/<?php echo $_smarty_tpl->tpl_vars['actual_page']->value-1;?>
' <?php } else { ?> href= '<?php echo BASE_URL;?>
home/1' <?php }?> tabindex="-1">&laquo;Anterior</a>
      </li> 
                       
      <?php
$_smarty_tpl->tpl_vars['i'] = new Smarty_Variable(null, $_smarty_tpl->isRenderingCache);$_smarty_tpl->tpl_vars['i']->step = 1;$_smarty_tpl->tpl_vars['i']->total = (int) ceil(($_smarty_tpl->tpl_vars['i']->step > 0 ? $_smarty_tpl->tpl_vars['tot_paginas']->value+1 - (1) : 1-($_smarty_tpl->tpl_vars['tot_paginas']->value)+1)/abs($_smarty_tpl->tpl_vars['i']->step));
if ($_smarty_tpl->tpl_vars['i']->total > 0) {
for ($_smarty_tpl->tpl_vars['i']->value = 1, $_smarty_tpl->tpl_vars['i']->iteration = 1;$_smarty_tpl->tpl_vars['i']->iteration <= $_smarty_tpl->tpl_vars['i']->total;$_smarty_tpl->tpl_vars['i']->value += $_smarty_tpl->tpl_vars['i']->step, $_smarty_tpl->tpl_vars['i']->iteration++) {
$_smarty_tpl->tpl_vars['i']->first = $_smarty_tpl->tpl_vars['i']->iteration === 1;$_smarty_tpl->tpl_vars['i']->last = $_smarty_tpl->tpl_vars['i']->iteration === $_smarty_tpl->tpl_vars['i']->total;?>
          <?php if ($_smarty_tpl->tpl_vars['actual_page']->value == $_smarty_tpl->tpl_vars['i']->value) {?>
              <li class="page-item active"><a class="page-link" href='<?php echo BASE_URL;?>
home/<?php echo $_smarty_tpl->tpl_vars['i']->value;?>
'><?php echo $_smarty_tpl->tpl_vars['i']->value;?>
 <span class="sr-only">(current)</span></a></li>
          <?php } else { ?>
              <li class="page-item"><a class="page-link" href='<?php echo BASE_URL;?>
home/<?php echo $_smarty_tpl->tpl_vars['i']->value;?>
'><?php echo $_smarty_tpl->tpl_vars['i']->value;?>
 <span class="sr-only">(current)</span></a></li>
          <?php }?>
      <?php }
}
?> 

      <li class="page-item">
          <a class="page-link" <?php if ($_smarty_tpl->tpl_vars['actual_page']->value == sprintf("%d",(($_smarty_tpl->tpl_vars['tot_paginas']->value)+1))) {?> href='<?php echo BASE_URL;?>
home/<?php echo $_smarty_tpl->tpl_vars['actual_page']->value;?>
' <?php } else { ?> href='<?php echo BASE_URL;?>
home/<?php echo $_smarty_tpl->tpl_vars['actual_page']->value+1;?>
' <?php }?>>&raquo;Siguiente</a>
      </li> 
    </ul>
  </nav>
  </div>
</div> 
<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>    

<?php }
}
