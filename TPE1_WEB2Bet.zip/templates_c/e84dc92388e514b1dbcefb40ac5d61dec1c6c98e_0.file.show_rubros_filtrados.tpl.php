<?php
/* Smarty version 3.1.34-dev-7, created on 2020-11-30 23:15:42
  from 'C:\xampp\htdocs\WEB2\TPE1_WEB2\templates\show_rubros_filtrados.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5fc56f0ed59fe0_92376908',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e84dc92388e514b1dbcefb40ac5d61dec1c6c98e' => 
    array (
      0 => 'C:\\xampp\\htdocs\\WEB2\\TPE1_WEB2\\templates\\show_rubros_filtrados.tpl',
      1 => 1606517026,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
  ),
),false)) {
function content_5fc56f0ed59fe0_92376908 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<div class="col-2 ">
   <ul class='list-group'  style='max-width: 200px'  >
        <a class='list-group-item list-group-item-action text-white bg-success'   href='<?php echo BASE_URL;?>
home'>TODOS</a>
        <a class='list-group-item list-group-item-action text-white bg-dark' href='<?php echo BASE_URL;?>
filtrar/<?php echo $_smarty_tpl->tpl_vars['rubro']->value->id;?>
'><?php echo $_smarty_tpl->tpl_vars['rubro']->value->descripcion;?>
</a>
   </ul> 
 </div><?php }
}
