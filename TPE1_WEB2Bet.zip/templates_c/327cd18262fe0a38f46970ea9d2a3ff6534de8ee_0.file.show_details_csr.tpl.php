<?php
/* Smarty version 3.1.34-dev-7, created on 2020-12-01 23:57:28
  from 'C:\xampp\htdocs\WEB2\TPE1_WEB2\templates\show_details_csr.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5fc6ca58d49e57_07280691',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '327cd18262fe0a38f46970ea9d2a3ff6534de8ee' => 
    array (
      0 => 'C:\\xampp\\htdocs\\WEB2\\TPE1_WEB2\\templates\\show_details_csr.tpl',
      1 => 1606863441,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:show_details.tpl' => 1,
    'file:vue/comments.vue' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_5fc6ca58d49e57_07280691 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender('file:header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
    <div class="container"> 
        <div class="row">
            <div class="col-md-4">
                <?php $_smarty_tpl->_subTemplateRender('file:show_details.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('upload'=>false), 0, false);
?>
            </div>
           
            <div class="col-md-8">
                <h2 class="text-white bg-dark"> Comentarios</h2>
                <?php if (((isset($_SESSION['EMAIL_USER'])) && ($_SESSION['ROL_USER'] == 1))) {?>  
                <div class="form-group col-md-6">
                    <form id="form_alta_comment" name="form_alta_comment" class="form-inline">
                        <div class="form-group col-md-12">
                           <h4>Califica el producto</h4>
                        </div>
                        <div class="form-check form-group col-md-3 ">
                            <input class="form-check-input" type="radio" name="r_button_score" id="r_button_score1" value="1" checked>
                            <label class="form-check-label" for="r_button_score"> 1 </label>
                        </div>
                        <div class="form-check form-group col-md-3">
                            <input class="form-check-input" type="radio" name="r_button_score" id="r_button_score2" value="2">
                            <label class="form-check-label" for="r_button_score"> 2 </label>
                        </div>
                        <div class="form-check form-group col-md-3">
                            <input class="form-check-input" type="radio" name="r_button_score" id="r_button_score3" value="3" >
                            <label class="form-check-label" for="r_button_score"> 3 </label>
                        </div>
                        <div class="form-check form-group col-md-3">
                            <input class="form-check-input" type="radio" name="r_button_score" id="r_button_score4" value="4">
                            <label class="form-check-label" for="r_button_score"> 4 </label>
                        </div>
                        <div class="form-check form-group col-md-3">
                            <input class="form-check-input" type="radio" name="r_button_score" id="r_button_score5" value="5" >
                            <label class="form-check-label" for="r_button_score"> 5 </label>
                        </div>
                        </div>
                       <div class="row">
                          <div class="col-12 form-group">
                             <textarea id="det_comment" name="det_comment" class="form-control md-8"  placeholder="Escribe tu comentario" ></textarea>
                           </div>
                        </div>
                       
                          <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Agregar</button>
                        
                    </form>
                    <?php }?>
                    <?php $_smarty_tpl->_subTemplateRender("file:vue/comments.vue", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
                </div>
            </div>
           
        </div>
    </div>

    <!--  JS para CSR -->
      <?php echo '<script'; ?>
 src="../js/comments.js"><?php echo '</script'; ?>
>    
     <?php echo '<script'; ?>
 src="../js/addcomment.js"><?php echo '</script'; ?>
> 
    <?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
</body>
</html>    <?php }
}
