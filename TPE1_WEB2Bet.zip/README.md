# Maquinarias Agricolas

Para TPE Web 2 Tudai Tres Arroyos

## Importar DB

1. Abrir phpMyAdmin
2. Crear la base de datos con el nombre `db_maqagricolas`;
3. Entrar a la base de datos recien creada e "IMPORTAR" desde el menú superior
4. Seleccionar "importar archivo" y elegir el file `database/db_maqagricolas.sql`.
5. Apretar CONTINUAR

Usuarios administradores:
 admin@prueba.com   password tudai2020
 admin@demo.com     password 123456
